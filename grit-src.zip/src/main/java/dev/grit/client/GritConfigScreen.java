package dev.grit.client;

import dev.grit.sound.GritSound;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.OptionListWidget;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Экран личных настроек Grit (открывается из Mod Menu).
 * Собран из ванильных виджетов — как вкладка «Музыка и звуки», без сторонних библиотек.
 * Здесь только то, что не влияет на баланс: громкость звуков, подписи и внешний вид.
 */
public class GritConfigScreen extends Screen {
	@Nullable
	private final Screen parent;
	private OptionListWidget list;

	public GritConfigScreen(@Nullable Screen parent) {
		super(Text.translatable("config.grit.title"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		GritClientConfig config = GritClientConfig.get();

		list = new OptionListWidget(client, width, height, 32, height - 32, 25);

		List<SimpleOption<?>> sounds = new ArrayList<>();
		for (GritSound sound : GritSound.values()) {
			sounds.add(volumeOption(sound, config));
		}
		list.addAll(sounds.toArray(new SimpleOption<?>[0]));

		list.addAll(new SimpleOption<?>[]{
				toggle("config.grit.other_players_fire", config.otherPlayersFire, v -> config.otherPlayersFire = v),
				toggle("config.grit.show_messages", config.showMessages, v -> config.showMessages = v),
				toggle("config.grit.frozen_elytra_model", config.frozenElytraModel, v -> config.frozenElytraModel = v),
				toggle("config.grit.frozen_elytra_icon", config.frozenElytraIcon, v -> config.frozenElytraIcon = v),
				toggle("config.grit.frozen_elytra_tooltip", config.frozenElytraTooltip, v -> config.frozenElytraTooltip = v),
		});

		addSelectableChild(list);
		addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, button -> close())
				.dimensions(width / 2 - 100, height - 27, 200, 20)
				.build());
	}

	private static SimpleOption<Double> volumeOption(GritSound sound, GritClientConfig config) {
		String key = "config.grit.sound." + sound.key();
		return new SimpleOption<>(
				key,
				SimpleOption.constantTooltip(Text.translatable(key + ".tooltip")),
				(optionText, value) -> value <= 0.0
						? ScreenTexts.composeGenericOptionText(optionText, ScreenTexts.OFF)
						: Text.translatable("options.percent_value", optionText, (int) Math.round(value * 100.0)),
				SimpleOption.DoubleSliderCallbacks.INSTANCE,
				(double) config.volume(sound),
				value -> config.setVolume(sound, value));
	}

	private static SimpleOption<Boolean> toggle(String key, boolean value, java.util.function.Consumer<Boolean> setter) {
		return SimpleOption.ofBoolean(key, SimpleOption.constantTooltip(Text.translatable(key + ".tooltip")), value, setter);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		renderBackground(context);
		list.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 15, 0xFFFFFF);
		super.render(context, mouseX, mouseY, delta);
	}

	@Override
	public void close() {
		GritClientConfig.get().save();
		if (client != null) client.setScreen(parent);
	}
}
