package dev.grit.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.grit.Grit;
import dev.grit.sound.GritSound;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Личные настройки игрока (config/grit-client.json). Ничего здесь не влияет на баланс:
 * только звуки, сообщения и внешний вид. Меняются через Mod Menu.
 */
public class GritClientConfig {
	/** Подписи Grit над хотбаром («Ноша тяжела», «Темнота шепчет…» и т.д.). */
	public boolean showMessages = true;
	/** Ледяная текстура обледеневших элитр на спине. */
	public boolean frozenElytraModel = true;
	/** Ледяная иконка обледеневших элитр в инвентаре. */
	public boolean frozenElytraIcon = true;
	/** Подсказка с таймером оттаивания на элитрах. */
	public boolean frozenElytraTooltip = true;
	/** Слышать треск огня в руках у других игроков (свой слышно всегда, если громкость > 0). */
	public boolean otherPlayersFire = true;
	/** Громкость каждого звука мода, 0.0–1.0. */
	public Map<String, Double> soundVolumes = new LinkedHashMap<>();

	private static GritClientConfig instance;

	public static GritClientConfig get() {
		if (instance == null) instance = load();
		return instance;
	}

	public float volume(GritSound sound) {
		Double v = soundVolumes.get(sound.key());
		return v == null ? 1.0f : (float) Math.max(0.0, Math.min(1.0, v));
	}

	public void setVolume(GritSound sound, double value) {
		soundVolumes.put(sound.key(), Math.max(0.0, Math.min(1.0, value)));
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("grit-client.json");
	}

	private static GritClientConfig load() {
		GritClientConfig config = new GritClientConfig();
		Path path = path();
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				GritClientConfig read = GSON.fromJson(reader, GritClientConfig.class);
				if (read != null) config = read;
			} catch (Exception e) {
				Grit.LOGGER.error("Failed to read config/grit-client.json, using defaults", e);
			}
		}
		if (config.soundVolumes == null) config.soundVolumes = new LinkedHashMap<>();
		for (GritSound sound : GritSound.values()) {
			config.soundVolumes.putIfAbsent(sound.key(), 1.0);
		}
		config.save();
		return config;
	}

	public void save() {
		try (Writer writer = Files.newBufferedWriter(path(), StandardCharsets.UTF_8)) {
			GSON.toJson(this, writer);
		} catch (Exception e) {
			Grit.LOGGER.error("Failed to write config/grit-client.json", e);
		}
	}
}
