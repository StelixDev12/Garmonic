package dev.grit.client;

import dev.grit.Grit;
import dev.grit.mechanic.FrozenElytra;
import dev.grit.network.GritNetwork;
import dev.grit.sound.GritSound;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.Map;
import java.util.WeakHashMap;

public class GritClient implements ClientModInitializer {
	/** Базовая громкость треска огня в руке — тихо. Ползунок в настройках умножает её. */
	private static final float HELD_FIRE_VOLUME = 0.3f;
	private static final double HELD_FIRE_DISTANCE = 16.0;

	private final Map<PlayerEntity, Integer> fireCooldowns = new WeakHashMap<>();
	private final Random random = Random.create();

	@Override
	public void onInitializeClient() {
		GritClientConfig.get();

		// Иконка: модель элитр переключается на ледяную, пока они обледеневшие
		// (см. assets/minecraft/models/item/elytra.json).
		FabricModelPredicateProviderRegistry.register(Items.ELYTRA, new Identifier(Grit.MOD_ID, "frozen"),
				(stack, world, entity, seed) ->
						GritClientConfig.get().frozenElytraIcon && FrozenElytra.isFrozen(stack) ? 1.0f : 0.0f);

		ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
			if (!GritClientConfig.get().frozenElytraTooltip) return;
			int ticks = FrozenElytra.getTicks(stack);
			if (ticks > 0) {
				int seconds = (ticks + 19) / 20;
				lines.add(Text.translatable("tooltip.grit.elytra.frozen", seconds).formatted(Formatting.AQUA));
			}
		});

		// Подписи Grit над хотбаром можно выключить.
		ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) ->
				!overlay || GritClientConfig.get().showMessages || !isGritMessage(message));

		// Звуки от сервера — с личной громкостью игрока.
		ClientPlayNetworking.registerGlobalReceiver(GritNetwork.SOUND, (client, handler, buf, responseSender) -> {
			int index = buf.readVarInt();
			double x = buf.readDouble();
			double y = buf.readDouble();
			double z = buf.readDouble();
			float volume = buf.readFloat();
			float pitch = buf.readFloat();
			if (index < 0 || index >= GritSound.values().length) return;
			GritSound sound = GritSound.values()[index];
			client.execute(() -> play(client, sound, x, y, z, volume, pitch));
		});

		ClientTickEvents.END_CLIENT_TICK.register(this::tickHeldFire);
	}

	private static boolean isGritMessage(Text message) {
		return message.getContent() instanceof TranslatableTextContent content
				&& content.getKey().startsWith("message.grit.");
	}

	private static void play(MinecraftClient client, GritSound sound, double x, double y, double z, float volume, float pitch) {
		ClientWorld world = client.world;
		if (world == null) return;
		float finalVolume = volume * GritClientConfig.get().volume(sound);
		SoundEvent event = sound.event();
		if (finalVolume <= 0.001f || event == null) return;
		world.playSound(x, y, z, event, sound.category, finalVolume, pitch, false);
	}

	/** Треск огня у факелов и костров в руках — свой и (по желанию) других игроков. */
	private void tickHeldFire(MinecraftClient client) {
		ClientWorld world = client.world;
		if (world == null || client.player == null || client.isPaused()) return;
		GritClientConfig config = GritClientConfig.get();

		for (PlayerEntity player : world.getPlayers()) {
			if (player.isSpectator()) continue;
			boolean self = player == client.player;
			if (!self && (!config.otherPlayersFire || player.squaredDistanceTo(client.player) > HELD_FIRE_DISTANCE * HELD_FIRE_DISTANCE)) {
				continue;
			}

			GritSound sound = GritSound.heldFire(player.getMainHandStack());
			if (sound == null) sound = GritSound.heldFire(player.getOffHandStack());
			if (sound == null) {
				fireCooldowns.remove(player);
				continue;
			}

			int cooldown = fireCooldowns.getOrDefault(player, random.nextInt(20));
			if (cooldown > 0) {
				fireCooldowns.put(player, cooldown - 1);
				continue;
			}
			fireCooldowns.put(player, 30 + random.nextInt(40));
			play(client, sound, player.getX(), player.getEyeY() - 0.4, player.getZ(),
					HELD_FIRE_VOLUME + random.nextFloat() * 0.1f, 0.8f + random.nextFloat() * 0.4f);
		}
	}
}
