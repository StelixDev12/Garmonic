package dev.grit.client;

import dev.grit.Grit;
import dev.grit.mechanic.FrozenElytra;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public class GritClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Иконка: модель элитр переключается на ледяную, пока они обледеневшие
		// (см. assets/minecraft/models/item/elytra.json).
		FabricModelPredicateProviderRegistry.register(Items.ELYTRA, new Identifier(Grit.MOD_ID, "frozen"),
				(stack, world, entity, seed) -> FrozenElytra.isFrozen(stack) ? 1.0f : 0.0f);

		ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
			int ticks = FrozenElytra.getTicks(stack);
			if (ticks > 0) {
				int seconds = (ticks + 19) / 20;
				lines.add(Text.translatable("tooltip.grit.elytra.frozen", seconds).formatted(Formatting.AQUA));
			}
		});
	}
}
