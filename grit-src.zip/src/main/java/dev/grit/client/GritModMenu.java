package dev.grit.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Кнопка «Настроить» в Mod Menu. Если Mod Menu не установлен, этот класс просто не загружается.
 */
public class GritModMenu implements ModMenuApi {
	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return GritConfigScreen::new;
	}
}
