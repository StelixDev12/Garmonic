package dev.grit.client;

import dev.grit.sound.GritSound;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.random.Random;

/**
 * Непрерывный звук горения огня в руке: зациклен, следует за игроком
 * и сам затихает, как только факел/костёр убран из рук.
 */
public class HeldFireSound extends MovingSoundInstance {
	/** Базовая громкость — тихо. Ползунок в настройках умножает её. */
	public static final float BASE_VOLUME = 0.35f;

	private final PlayerEntity player;
	private final GritSound type;

	public HeldFireSound(PlayerEntity player, GritSound type, SoundEvent event, Random random) {
		super(event, type.category, random);
		this.player = player;
		this.type = type;
		this.repeat = true;
		this.repeatDelay = 0;
		this.attenuationType = SoundInstance.AttenuationType.LINEAR;
		this.pitch = 1.0f;
		updatePosition();
		this.volume = targetVolume();
	}

	public GritSound type() {
		return type;
	}

	@Override
	public void tick() {
		if (player.isRemoved() || player.isSpectator() || GritClient.heldFireOf(player) != type) {
			setDone();
			return;
		}
		updatePosition();
		this.volume = targetVolume();
	}

	private float targetVolume() {
		return BASE_VOLUME * GritClientConfig.get().volume(type);
	}

	private void updatePosition() {
		this.x = player.getX();
		this.y = player.getEyeY() - 0.4;
		this.z = player.getZ();
	}
}
