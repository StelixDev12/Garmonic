package dev.grit.mechanic;

import dev.grit.registry.ModEnchantments;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;

/**
 * Обледенение хранится прямо на предмете (NBT "GritFrozen" = сколько тиков ещё оттаивать),
 * поэтому клиент видит его без пакетов: меняется иконка, модель на спине и подсказка.
 */
public final class FrozenElytra {
	public static final String KEY = "GritFrozen";

	private FrozenElytra() {}

	public static boolean isFrozen(ItemStack stack) {
		return getTicks(stack) > 0;
	}

	public static int getTicks(ItemStack stack) {
		if (!stack.isOf(Items.ELYTRA)) return 0;
		NbtCompound nbt = stack.getNbt();
		return nbt == null ? 0 : nbt.getInt(KEY);
	}

	public static void setTicks(ItemStack stack, int ticks) {
		if (ticks > 0) {
			stack.getOrCreateNbt().putInt(KEY, ticks);
		} else if (stack.hasNbt()) {
			stack.removeSubNbt(KEY);
			if (stack.getNbt() != null && stack.getNbt().isEmpty()) {
				stack.setNbt(null);
			}
		}
	}

	public static boolean resistsIcing(ItemStack stack) {
		return EnchantmentHelper.getLevel(ModEnchantments.ICING_RESISTANCE, stack) > 0;
	}
}
