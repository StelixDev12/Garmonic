package dev.grit.mechanic;

import dev.grit.Grit;
import dev.grit.GritConfig;
import dev.grit.registry.ModEffects;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

/** Переломы: тяжёлое падение может сломать ногу. Броня и её твёрдость снижают шанс. */
public final class WoundHandler {
	private WoundHandler() {}

	public static boolean onDamage(LivingEntity entity, DamageSource source, float amount) {
		if (!(entity instanceof ServerPlayerEntity player) || player.isCreative() || player.isSpectator()) {
			return true;
		}
		GritConfig.Wounds cfg = Grit.CONFIG.wounds;
		if (cfg.fractures && source.isIn(DamageTypeTags.IS_FALL)) {
			tryFracture(player, amount, cfg);
		}
		return true; // урон никогда не отменяем, только добавляем последствия
	}

	/**
	 * Броня гасит удар о землю: важны и очки брони, и твёрдость.
	 * По умолчанию: кожа ≈ 17%, железо ≈ 37%, алмаз ≈ 70%, незерит ≈ 80% (предел 85%).
	 */
	private static double armorProtection(ServerPlayerEntity player, GritConfig.Wounds cfg) {
		double armor = MathHelper.clamp(player.getArmor() / 20.0, 0.0, 1.0);
		double toughness = MathHelper.clamp(player.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS) / 12.0, 0.0, 1.0);
		double protection = armor * cfg.armorProtection + toughness * cfg.toughnessProtection;
		return MathHelper.clamp(protection, 0.0, cfg.maxProtection);
	}

	private static boolean hasFeatherFalling(ServerPlayerEntity player) {
		ItemStack boots = player.getEquippedStack(EquipmentSlot.FEET);
		return EnchantmentHelper.getLevel(Enchantments.FEATHER_FALLING, boots) > 0;
	}

	private static void tryFracture(ServerPlayerEntity player, float amount, GritConfig.Wounds cfg) {
		float min = cfg.fractureMinFallDamage;
		if (amount < min) return;

		double chance = amount >= min + 4 ? 1.0 : 0.4 + (amount - min) * 0.15;
		chance *= 1.0 - armorProtection(player, cfg);

		// «Невесомость» на ботинках: если броня уже снизила шанс ниже порога, мелкие и средние
		// падения не ломают ногу вовсе, а падения с большой высоты — лишь с фиксированным малым шансом.
		if (chance < cfg.featherFallingThreshold && hasFeatherFalling(player)) {
			if (player.fallDistance <= cfg.featherFallingMinHeight) return;
			if (amount <= cfg.featherFallingMinDamage) return;
			chance = cfg.featherFallingChance;
		}
		if (player.getRandom().nextDouble() >= chance) return;

		StatusEffectInstance current = player.getStatusEffect(ModEffects.FRACTURE);
		int amplifier = current == null ? 0 : 1;
		player.addStatusEffect(new StatusEffectInstance(ModEffects.FRACTURE, 20 * cfg.fractureSeconds, amplifier, false, true, true));
		player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ENTITY_SKELETON_HURT, SoundCategory.PLAYERS, 1.0f, 0.6f);
		player.sendMessage(Text.translatable("message.grit.fracture").formatted(Formatting.RED), true);
	}
}
