package dev.grit.mechanic;

import dev.grit.Grit;
import dev.grit.GritConfig;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

/**
 * Вода в лёгких. Если воздух под водой закончился и вы начали задыхаться, то после всплытия
 * ещё 2–6 секунд (случайно) откашливаете воду: урон от утопления продолжается,
 * а пузырьки воздуха не восстанавливаются.
 * Подводное дыхание и сила источника сразу прекращают эффект.
 */
public final class LungsHandler {
	private LungsHandler() {}

	public static void tick(ServerPlayerEntity player, PlayerState state, int tick) {
		GritConfig.Lungs cfg = Grit.CONFIG.lungs;

		if (player.hasStatusEffect(StatusEffects.WATER_BREATHING) || player.hasStatusEffect(StatusEffects.CONDUIT_POWER)) {
			reset(state);
			return;
		}

		boolean underwater = player.isSubmergedIn(FluidTags.WATER);
		if (underwater) {
			state.lungTicks = 0;
			if (player.getAir() <= 0) {
				state.choked = true; // начали задыхаться — вода попала в лёгкие
			}
			return;
		}

		if (!state.choked) return;

		// Только что всплыли — бросаем кубик, сколько ещё откашливаться.
		if (state.lungTicks <= 0) {
			int min = Math.max(0, cfg.minSeconds) * 20;
			int max = Math.max(cfg.minSeconds, cfg.maxSeconds) * 20;
			state.lungTicks = min + player.getRandom().nextInt(max - min + 1);
			if (state.lungTicks <= 0) {
				reset(state);
				return;
			}
			player.sendMessage(Text.translatable("message.grit.lungs").formatted(Formatting.AQUA), true);
		}

		// Ваниль на суше прибавляет воздух — держим его на нуле.
		player.setAir(0);

		if (state.lungTicks % 20 == 0) {
			player.damage(player.getDamageSources().drown(), cfg.damagePerSecond);
			cough(player);
		}

		state.lungTicks--;
		if (state.lungTicks <= 0) {
			reset(state); // откашлялись — воздух восстанавливается как обычно
		}
	}

	private static void cough(ServerPlayerEntity player) {
		if (!(player.getWorld() instanceof ServerWorld world)) return;
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d mouth = player.getEyePos().add(look.multiply(0.4)).add(0, -0.15, 0);
		world.spawnParticles(ParticleTypes.SPLASH, mouth.x, mouth.y, mouth.z, 10, 0.1, 0.05, 0.1, 0.2);
	}

	public static void reset(PlayerState state) {
		state.choked = false;
		state.lungTicks = 0;
	}
}
