package dev.grit.mechanic;

import dev.grit.Grit;
import dev.grit.GritConfig;
import dev.grit.network.GritNetwork;
import dev.grit.sound.GritSound;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Потолок для элитр.
 *  - Выше maxHeight (Y=250) элитры не раскрываются.
 *  - Раскрытые элитры через graceSeconds (4 с) над потолком обледеневают и складываются.
 *  - Обледеневшие элитры не раскрываются нигде 30 секунд. Отсчёт идёт, только когда игрок
 *    ниже потолка или элитры сняты (лежат в инвентаре).
 *  - «Сопротивление обледенению» снимает все эти ограничения.
 *
 * Работает через событие Fabric API EntityElytraEvents.ALLOW: оно проверяется и при попытке
 * раскрыть элитры (на клиенте и сервере), и каждый тик полёта — без мерцания.
 */
public final class ElytraHandler {
	private ElytraHandler() {}

	/** Слушатель EntityElytraEvents.ALLOW. */
	public static boolean allowFlight(LivingEntity entity) {
		GritConfig.Elytra cfg = Grit.CONFIG.elytra;
		if (!cfg.enabled || !(entity instanceof PlayerEntity player)) return true;
		if (player.isCreative() || player.isSpectator()) return true;

		ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
		if (FrozenElytra.resistsIcing(chest)) return true;
		if (FrozenElytra.isFrozen(chest)) return false; // обледенели — ждём оттаивания
		if (player.getY() <= cfg.maxHeight) return true;

		// Выше потолка раскрыть нельзя.
		if (!player.isFallFlying()) return false;

		// Уже летим: решает сервер — складываем после отсрочки.
		if (player instanceof ServerPlayerEntity serverPlayer) {
			return PlayerState.of(serverPlayer).ticksAboveCeiling < cfg.graceSeconds * 20;
		}
		return true;
	}

	/** Серверный тик. */
	public static void tick(ServerPlayerEntity player, PlayerState state, int tick) {
		GritConfig.Elytra cfg = Grit.CONFIG.elytra;
		ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
		boolean aboveCeiling = player.getY() > cfg.maxHeight;

		if ((tick + player.getId()) % 20 == 0) {
			thaw(player, chest, aboveCeiling, cfg);
		}

		if (!aboveCeiling || FrozenElytra.resistsIcing(chest)) {
			state.ticksAboveCeiling = 0;
			return;
		}
		if (!player.isFallFlying() && state.ticksAboveCeiling == 0) {
			return; // просто стоим на высокой горе или постройке — считать нечего
		}

		state.ticksAboveCeiling++;
		int grace = cfg.graceSeconds * 20;
		if (state.ticksAboveCeiling == 1 && player.isFallFlying()) {
			player.sendMessage(Text.translatable("message.grit.elytra.thin_air").formatted(Formatting.YELLOW), true);
		} else if (state.ticksAboveCeiling == grace && player.isFallFlying() && chest.isOf(Items.ELYTRA)) {
			FrozenElytra.setTicks(chest, cfg.frozenSeconds * 20);
			player.stopFallFlying();
			GritNetwork.playNear((ServerWorld) player.getWorld(), GritSound.ELYTRA_FREEZE, player.getX(), player.getY(), player.getZ(), 0.8f, 1.6f);
			player.sendMessage(Text.translatable("message.grit.elytra.frozen", cfg.frozenSeconds).formatted(Formatting.AQUA), true);
		}
	}

	/** Раз в секунду: оттаивают все обледеневшие элитры игрока, кроме надетых выше потолка. */
	private static void thaw(ServerPlayerEntity player, ItemStack chest, boolean aboveCeiling, GritConfig.Elytra cfg) {
		PlayerInventory inventory = player.getInventory();
		for (int i = 0; i < inventory.size(); i++) {
			ItemStack stack = inventory.getStack(i);
			int left = FrozenElytra.getTicks(stack);
			if (left <= 0) continue;
			if (stack == chest && aboveCeiling) continue;

			left -= 20;
			FrozenElytra.setTicks(stack, left);
			if (left <= 0) {
				GritNetwork.playTo(player, GritSound.ELYTRA_THAW, player.getX(), player.getY(), player.getZ(), 1.0f, 1.0f);
				player.sendMessage(Text.translatable("message.grit.elytra.thawed").formatted(Formatting.GREEN), true);
			}
		}
	}

	public static void reset(PlayerState state) {
		state.ticksAboveCeiling = 0;
	}
}
