package dev.grit.mechanic;

import dev.grit.Grit;
import dev.grit.GritConfig;
import dev.grit.registry.ModGameEvents;
import dev.grit.sound.GritSound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.event.GameEvent;

/**
 * Огонь в руке (факел, факел душ, костёр, костёр душ) тихо потрескивает.
 * Сервер отвечает только за вибрацию — её слышат скалк-сенсоры и варден.
 * Сам звук каждый клиент проигрывает у себя (см. GritClient), с громкостью из своих настроек.
 */
public final class HeldFireHandler {
	private HeldFireHandler() {}

	public static void tick(ServerPlayerEntity player, PlayerState state) {
		GritConfig.HeldFire cfg = Grit.CONFIG.heldFire;
		boolean holding = GritSound.heldFire(player.getMainHandStack()) != null
				|| GritSound.heldFire(player.getOffHandStack()) != null;
		if (!holding) {
			state.fireCrackleCooldown = 0;
			return;
		}
		if (state.fireCrackleCooldown > 0) {
			state.fireCrackleCooldown--;
			return;
		}
		GameEvent crackle = ModGameEvents.fireCrackle();
		if (crackle != null) {
			player.emitGameEvent(crackle);
		}
		int min = Math.max(1, cfg.minIntervalTicks);
		int max = Math.max(min, cfg.maxIntervalTicks);
		state.fireCrackleCooldown = min + player.getRandom().nextInt(max - min + 1);
	}
}
