package dev.grit.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * «Сопротивление обледенению» — сокровищное зачарование только для элитр.
 * Элитры с ним не обледеневают и раскрываются выше потолка высоты.
 * Нельзя получить на столе зачарований и у жителей — только книгой из сундуков
 * древнего города (1%) и сокровищницы бастиона (5%).
 */
public class IcingResistanceEnchantment extends Enchantment {
	public IcingResistanceEnchantment() {
		super(Rarity.VERY_RARE, EnchantmentTarget.BREAKABLE, new EquipmentSlot[]{EquipmentSlot.CHEST});
	}

	@Override
	public boolean isAcceptableItem(ItemStack stack) {
		return stack.isOf(Items.ELYTRA);
	}

	@Override
	public int getMinPower(int level) {
		return 25;
	}

	@Override
	public int getMaxPower(int level) {
		return 50;
	}

	@Override
	public int getMaxLevel() {
		return 1;
	}

	@Override
	public boolean isTreasure() {
		return true;
	}

	@Override
	public boolean isAvailableForEnchantedBookOffer() {
		return false;
	}

	@Override
	public boolean isAvailableForRandomSelection() {
		return false;
	}
}
