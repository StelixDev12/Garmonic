package dev.grit.mixin.client;

import dev.grit.client.GritClientConfig;
import dev.grit.mechanic.FrozenElytra;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Обледеневшие элитры на спине получают ледяную текстуру — но только если вместо неё
 * не рисуется плащ игрока (тогда меняется лишь иконка в инвентаре).
 * require = 0: если другой мод поменял этот рендер, мы просто не меняем текстуру, а не падаем.
 */
@Mixin(ElytraFeatureRenderer.class)
public abstract class ElytraFeatureRendererMixin {
	@Unique
	private static final Identifier GRIT_VANILLA_ELYTRA = new Identifier("textures/entity/elytra.png");
	@Unique
	private static final Identifier GRIT_FROZEN_ELYTRA = new Identifier("grit", "textures/entity/frozen_elytra.png");
	@Unique
	private static boolean grit$frozen;

	@Inject(
			method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V",
			at = @At("HEAD"),
			require = 0)
	private void grit$captureFrozen(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, LivingEntity entity,
									float limbAngle, float limbDistance, float tickDelta, float animationProgress,
									float headYaw, float headPitch, CallbackInfo ci) {
		grit$frozen = GritClientConfig.get().frozenElytraModel
				&& FrozenElytra.isFrozen(entity.getEquippedStack(EquipmentSlot.CHEST));
	}

	@ModifyArg(
			method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/client/render/RenderLayer;getArmorCutoutNoCull(Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/render/RenderLayer;"),
			index = 0,
			require = 0)
	private Identifier grit$swapTexture(Identifier texture) {
		return grit$frozen && GRIT_VANILLA_ELYTRA.equals(texture) ? GRIT_FROZEN_ELYTRA : texture;
	}
}
