package dev.grit.sound;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

/**
 * Все звуки мода. Сервер не проигрывает их сам, а присылает клиенту команду —
 * клиент умножает громкость на ползунок из настроек игрока (у каждого звука свой).
 * Используются только ванильные звуковые файлы.
 */
public enum GritSound {
	DREAD_WHISPER("ambient.cave", SoundCategory.AMBIENT),
	DREAD_HEARTBEAT("entity.warden.heartbeat", SoundCategory.AMBIENT),
	FRACTURE("entity.skeleton.hurt", SoundCategory.PLAYERS),
	ELYTRA_FREEZE("block.glass.break", SoundCategory.PLAYERS),
	ELYTRA_THAW("block.pointed_dripstone.drip_water", SoundCategory.PLAYERS),
	HELD_TORCH("block.fire.ambient", SoundCategory.PLAYERS),
	HELD_SOUL_TORCH("block.fire.ambient", SoundCategory.PLAYERS),
	HELD_CAMPFIRE("block.fire.ambient", SoundCategory.PLAYERS),
	HELD_SOUL_CAMPFIRE("block.fire.ambient", SoundCategory.PLAYERS);

	private final Identifier soundId;
	public final SoundCategory category;

	GritSound(String vanillaId, SoundCategory category) {
		this.soundId = new Identifier("minecraft", vanillaId);
		this.category = category;
	}

	@Nullable
	public SoundEvent event() {
		return Registries.SOUND_EVENT.get(soundId);
	}

	/** Ключ в клиентском конфиге и в файлах перевода. */
	public String key() {
		return name().toLowerCase(java.util.Locale.ROOT);
	}

	/** Какой «огненный» звук издаёт предмет в руке (факел, факел душ, костёр, костёр душ). */
	@Nullable
	public static GritSound heldFire(ItemStack stack) {
		if (stack.isOf(Items.TORCH)) return HELD_TORCH;
		if (stack.isOf(Items.SOUL_TORCH)) return HELD_SOUL_TORCH;
		if (stack.isOf(Items.CAMPFIRE)) return HELD_CAMPFIRE;
		if (stack.isOf(Items.SOUL_CAMPFIRE)) return HELD_SOUL_CAMPFIRE;
		return null;
	}
}
