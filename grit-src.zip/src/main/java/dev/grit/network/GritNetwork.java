package dev.grit.network;

import dev.grit.Grit;
import dev.grit.sound.GritSound;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

/** Пакет «сыграй звук Grit»: клиент сам применяет громкость из настроек игрока. */
public final class GritNetwork {
	public static final Identifier SOUND = new Identifier(Grit.MOD_ID, "sound");
	private static final double HEAR_DISTANCE = 16.0;

	private GritNetwork() {}

	/** Звук только для одного игрока (например, шёпоты темноты). */
	public static void playTo(ServerPlayerEntity player, GritSound sound, double x, double y, double z, float volume, float pitch) {
		if (!ServerPlayNetworking.canSend(player, SOUND)) return;
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeVarInt(sound.ordinal());
		buf.writeDouble(x);
		buf.writeDouble(y);
		buf.writeDouble(z);
		buf.writeFloat(volume);
		buf.writeFloat(pitch);
		ServerPlayNetworking.send(player, SOUND, buf);
	}

	/** Звук, который слышат все игроки поблизости (например, хруст перелома). */
	public static void playNear(ServerWorld world, GritSound sound, double x, double y, double z, float volume, float pitch) {
		for (ServerPlayerEntity player : world.getPlayers()) {
			if (player.squaredDistanceTo(x, y, z) <= HEAR_DISTANCE * HEAR_DISTANCE) {
				playTo(player, sound, x, y, z, volume, pitch);
			}
		}
	}
}
