package dev.grit.registry;

import dev.grit.Grit;
import dev.grit.enchantment.IcingResistanceEnchantment;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.EnchantRandomlyLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEnchantments {
	public static final Enchantment ICING_RESISTANCE = new IcingResistanceEnchantment();

	/** Все сундуки древнего города. */
	private static final Identifier ANCIENT_CITY = new Identifier("minecraft", "chests/ancient_city");
	private static final Identifier ANCIENT_CITY_ICE_BOX = new Identifier("minecraft", "chests/ancient_city_ice_box");
	/** Главный сундук бастиона — сокровищница. */
	private static final Identifier BASTION_TREASURE = new Identifier("minecraft", "chests/bastion_treasure");

	private ModEnchantments() {}

	public static void register() {
		Registry.register(Registries.ENCHANTMENT, new Identifier(Grit.MOD_ID, "icing_resistance"), ICING_RESISTANCE);

		LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
			if (id.equals(ANCIENT_CITY) || id.equals(ANCIENT_CITY_ICE_BOX)) {
				tableBuilder.pool(bookPool(Grit.CONFIG.elytra.ancientCityBookChance));
			} else if (id.equals(BASTION_TREASURE)) {
				tableBuilder.pool(bookPool(Grit.CONFIG.elytra.bastionBookChance));
			}
		});
	}

	private static LootPool.Builder bookPool(float chance) {
		return LootPool.builder()
				.rolls(ConstantLootNumberProvider.create(1))
				.conditionally(RandomChanceLootCondition.builder(chance))
				.with(ItemEntry.builder(Items.BOOK)
						.apply(new EnchantRandomlyLootFunction.Builder().add(ICING_RESISTANCE)));
	}
}
