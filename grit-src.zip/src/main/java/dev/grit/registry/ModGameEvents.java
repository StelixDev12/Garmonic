package dev.grit.registry;

import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

/**
 * Вибрация от огня в руке. Используем ванильное событие entity_shake: у него есть законная частота
 * вибрации (своё событие без частоты может уронить игру у аметиста рядом со скалк-сенсором).
 * Оно не входит в ignore_vibrations_sneaking — огонь слышно, даже если игрок крадётся.
 * На всякий случай событие добавлено в теги #minecraft:vibrations и #minecraft:warden_can_listen.
 */
public final class ModGameEvents {
	private static final Identifier FIRE_CRACKLE_ID = new Identifier("minecraft", "entity_shake");

	private ModGameEvents() {}

	@Nullable
	public static GameEvent fireCrackle() {
		return Registries.GAME_EVENT.get(FIRE_CRACKLE_ID);
	}
}
